## descheduler version

Version of descheduler

### Synopsis

Prints the version of descheduler.

```
descheduler version [flags]
```

### Options

```
  -h, --help   help for version
```

### SEE ALSO

* [descheduler](descheduler.md)	 - descheduler

